package com.example.android_2_project

data class User(
    val uid: String? = "",
    val name: String? = "",
    val email: String? = "",
    val password: String? = "",
    val address: String? = "",
    val dob: String? = "",
)
