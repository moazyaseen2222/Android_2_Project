package com.example.android_2_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MyBooks : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_books)
    }
}